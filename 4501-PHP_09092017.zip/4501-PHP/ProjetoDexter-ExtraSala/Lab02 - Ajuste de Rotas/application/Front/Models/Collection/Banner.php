<?php

namespace DexterApp\Front\Models\Collection;

/**
 * Coleção de banners
 */
class Banner extends \ArrayObject
{
}
