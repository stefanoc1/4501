<?php

namespace DexterApp\Admin\Models\Collection;

class Servico extends \ArrayObject
{
}
