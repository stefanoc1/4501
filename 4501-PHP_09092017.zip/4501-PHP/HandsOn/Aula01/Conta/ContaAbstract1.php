<?php
//Conta usando p Abstract
abstract class Conta
{
	protected $titular;
	protected $saldo = 0;

	public function __construct ($titular, $saldo){
		$this->titular = $titular;
		$this->saldo = $saldo;
		echo "Bem vindo $titular, seu saldo atual e: $saldo<br>";
	}
/*
	public function depositar($valor) {
		echo "Saldo: {$this->saldo}<br>";
		$this->saldo += $valor;
		echo "Depositado: $valor<br>";
		echo "Saldo atual: {$this->saldo}<br>";
	}
*/
	abstract public function depositar($valor);

	public function sacar($valor) {
		if($valor > $this->saldo) {
			echo "Saldo insuficiente<br>";
			echo "Saldo atual $valor<br>";
		} else {
			echo "Saldo: {$this->saldo}<br>";
			$this->saldo -= $valor;
			echo "Debitos: $valor<br>";
			echo "Saldo atual: {$this->saldo}<br>";
		}
	}	

	public function verSaldo() {
		return $this->saldo;
	}
}

final class ContaCorrente extends Conta
{
	public function depositar($valor) {
		echo "Saldo: {$this->saldo}<br>";
		$this->saldo += $valor;
		echo "Creditos: $valor<br>";
		echo "Saldo em Conta Corrente: {$this->saldo}<br>";
	}
}
final class ContaPoupanca extends Conta
{
	public function depositar($valor) {
		$this->saldo += $valor + ($valor * 0.1);		
		echo "Creditos: $valor<br>";
		echo "Saldo em Conta Poupanca: {$this->saldo}<br>";
	}
}


$cliente = new ContaCorrente('Stefano', 500);
$cliente->depositar(90);
$cliente->sacar(10);
echo '<br>';
$cliente = new ContaPoupanca('Stefano', 1000);
$cliente->depositar(100);
$cliente->sacar(0);