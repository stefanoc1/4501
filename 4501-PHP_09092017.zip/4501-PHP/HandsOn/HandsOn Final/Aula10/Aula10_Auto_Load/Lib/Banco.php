<?php

namespace Lib;

class Banco
{
    public function __construct()
    {
        echo '<hr>Conectando ao banco....<hr>';
    }
}