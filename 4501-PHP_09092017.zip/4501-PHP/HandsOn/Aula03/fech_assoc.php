<?php

$dsn = 'pgsql:host=localhost;dbname=dexter';
$user = 'usuario_dexter';
$pass = '123456';

$pdo = new PDO($dsn, $user, $pass);

var_dump($pdo);

$prepare = $pdo->prepare('SELECT * FROM banners');
$prepare->execute();
$result = $prepare->fetch(PDO::FETCH_ASSOC);

var_dump($result);
