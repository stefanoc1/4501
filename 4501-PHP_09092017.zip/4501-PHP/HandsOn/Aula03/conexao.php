<?php
//Singleton
class conexao{

	public static $instance;

	private function __construct()
	{

	}

	public static function getInstance()
	{
		if(!isset(self::$instance))
		{
				//PDO
				$dsn = 'pgsql:host=localhost;dbname=dexter';
				$user = 'usuario_dexter';
				$pass = '123456';

				self::$instance = new PDO($dsn, $user, $pass);
		}
		return self::$instance;
	}
}

$conexao = conexao::getInstance();

var_dump($conexao);
