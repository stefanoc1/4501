<?php

class Pai
{
	protected static $nome = 'Classe Pai';

	public static function pegaNome()
	{
		return static::$nome;
	}
}

class Filha extends Pai
{
	protected static $nome = 'Classe Filha';
}

class Neto extends Filha
{
	protected static $nome = 'Classe Neto';
}
echo Filha::pegaNome()."<br/>";
echo Pai::pegaNome()."<br/>";
echo Neto::pegaNome()."<br/>";