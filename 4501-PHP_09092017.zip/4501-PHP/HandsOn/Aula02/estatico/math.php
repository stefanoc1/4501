<?php

class Math
{
//:: Soma($a,$b)
//:: Subtracao($a,$b)
//:: Multiplicacao($a,$b)
//:: Divisao($a,$b)

//	public $x=10;
//	public $y=2;

	public static function soma($a, $b)
	{
		return $a+$b;		
	}
	public static function subtracao($a, $b)
	{
		return $a-$b;		
	}
	public static function multiplicao($a, $b)
	{
		return $a*$b;		
	}
	public static function divisao($a, $b)
	{
		return $a/$b;		
	}
}

echo "<p>Soma</p>";
echo "<p>A+B=".Math::soma(10, 2)."</p>";
echo "<hr/>";
echo "<p>Subtracao</p>";
echo "<p>A-B=".Math::subtracao(10, 2)."</p>";
echo "<hr/>";
echo "<p>Multiplicacao</p>";
echo "<p>A*B=".Math::multiplicao(10, 2)."</p>";
echo "<hr/>";
echo "<p>Divisao</p>";
echo "<p>A/B=".Math::divisao(10, 2)."</p>";