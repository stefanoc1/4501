<?php

var_dump ($_SESSION);

if ($_POST) {
    if (verificarSenha ($senha, $confirmasenha))
    	logar($nome, $senha, $confirmasenha);
	}
}


$nome = $_POST['nome'];
$senha = $_POST['senha']; 
$confirma = $_POST['confirmasenha']; 

if ($_POST) {
    if ($senha === $confirma){
    session_start();
    $_SESSION['nome'] = $nome;
    $_SESSION['senha'] = $senha;
    $_SESSION['confirma'] = $confirma;
    }
}

function validasenha ($senha, $confirmasenha) {
	$senha = $confirmasenha



    if ($validasenha = 1)
        echo 'Senha valida';
    } else {
        echo 'Senha invalida';
}

function logar ($senha, $confirmasenha) {
	session_start();
	$_SESSION [nome] = $nome;
	$_SESSION [senha] = $senha;
	$_SESSION [verificarsenha] = $verificarsenha;
}


function deslogar(){
	return session_destroy();
}