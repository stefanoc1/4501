<?php
require 'Model.php';
require 'View.php';
require 'Controller.php';

(new Controller())->executar();
