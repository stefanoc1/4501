<?php

abstract class Validator

{
	public static function isValid($what)
	{
		$validator = new static();//cria a classe filha
		return $validator->validate($what);
	}
	abstract protected function validate($what);
}

class Interger extends Validator
{
	protected function validate($what)
	{
		return is_int($what);
	}
}
var_dump(interger::isValid(2));