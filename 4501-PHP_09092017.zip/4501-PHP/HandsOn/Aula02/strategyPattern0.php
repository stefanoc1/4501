<?php
//inicio da interface
interface FreteStrategy
{
	public function calcular($distancia);
}

class FreteNormal implements FreteStrategy
{
	public function calcular($distancia)
	{
		echo "<p>Frete normal </p>";
		return 2*$distancia;
		}
}

class FreteExpresso implements FreteStrategy
{
	public function calcular($distancia)
	{
		echo "<p>Frete expresso </p>";
		return 5*$distancia;
	}
}

class FreteTurbo implements FreteStrategy
{
	public function calcular($distancia)
	{
		echo "<p>Frete turbo </p>";
		return 10*$distancia;
	}
}
//final da interface
class Pedido
{
	private $freteStrategy;
	private $distancia;

	public function __construct(FreteStrategy $freteStrategy, $distancia)
	{
		$this->freteStrategy = $freteStrategy;
		$this->distancia = $distancia;
	}

	public function calcularTotalPedido()
	{
		$totalPedido = 10;
		$totalPedido = $this->distancia*$this->freteStrategy->calcular($this->distancia);
		return $totalPedido;
	}
}

$tipoFrete =10; //'frete_expresso';

if($tipoFrete === 2)//if($tipoFrete === 'frete_normal')
{
	$freteStrategy = new FreteNormal();
}

elseif($tipoFrete === 5)//elseif($tipoFrete === 'frete_expresso')
{
	$freteStrategy = new FreteExpress();
}

elseif($tipoFrete === 10)//elseif($tipoFrete === 'frete_turbo')
{
	$freteStrategy = new FreteTurbo();
}

$pedido = new Pedido($freteStrategy, 10);
echo "Total Pedido - R$ {$pedido->calcularTotalPedido()} reais";