<?php
echo '<pre>';
//var_dump ($_SERVER);
//var_dump ($_ENV);
var_dump ($GLOBALS);