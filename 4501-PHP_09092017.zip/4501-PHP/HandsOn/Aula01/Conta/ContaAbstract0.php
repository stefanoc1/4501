<?php
//Conta usando p Abstract
abstract class Conta
{
	protected $titular;
	protected $saldo = 0;

	public function __construct ($titular, $saldo){
		$this->titular = $titular;
		$this->saldo = $saldo;
		echo "Bem vindo $titular, seu saldo atual e: $saldo<br>";
	}

	public function depositar($valor) {
		echo "Saldo: {$this->saldo}<br>";
		$this->saldo += $valor;
		echo "Depositado: $valor<br>";
		echo "Saldo atual: {$this->saldo}<br>";
	}

	public function sacar($valor) {
		if($valor > $this->saldo) {
			echo "Saldo insuficiente<br>";
			echo "Saldo atual $valor<br>";
		} else {
			echo "Saldo: {$this->saldo}<br>";
			$this->saldo -= $valor;
			echo "Sacado: $valor<br>";
			echo "Saldo atual: {$this->saldo}<br>";
		}
	}	

	public function verSaldo() {
		return $this->saldo;
	}
}


class ContaCorrente extends Conta
{
	
	
}

class ContaPoupanca extends Conta
{
	
	
}


$cliente = new ContaCorrente('Stefano', 10);
$cliente->depositar(90);
$cliente->sacar(10);


