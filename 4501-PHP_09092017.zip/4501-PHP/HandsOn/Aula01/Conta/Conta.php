<?php
//Princi
class Conta
{
	public $nroConta;
	private $saldo = 0;

	public function verSaldo() {
		return $this->saldo;
	}

	public function depositar($valor) {
		$this->saldo += $valor;	
	}

	public function retirar($valor) {
		if($this->saldo -= $valor<0) {
			echo 'Retirada menor que saldo ';
		} else {
			$this->saldo -= $valor;
		}
	}
}

$conta1 = new Conta();

$conta1->depositar(50);
$conta1->retirar(45);
echo '<br>';
echo $conta1->verSaldo();


$joao = new Conta();

$joao->depositar(10000);
echo '<br>';
echo $joao->verSaldo();