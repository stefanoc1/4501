<?php
//Principio de encapsulamento
class Conta
{
	public $nroConta;
	private $saldo = 0;

	public function verSaldo() {
		return $this->saldo;
	}

	public function depositarSaldo($valor) {
		$this->saldo += $valor;	
	}

	public function retirarSaldo($valor) {
		if($this->saldo -= $valor <0) {
			echo 'Retirada maio que saldo ';
		} else {
			$this->saldo -= $valor;
		}
	}
}

$conta1 = new Conta();

$conta1->depositarSaldo(50);
$conta1->retirarSaldo(45);
echo '<br>';
echo $conta1->verSaldo();
?>