<?php

$artilheiro = 'Ronaldo';
$gols = 19;
echo '<pre>';
$formato = 'O artilheiro do brasileirao, %s, tem %d gols.';
printf($formato, $artilheiro, $gols);
echo '<pre>';
$formato = 'O artilheiro do brasileirao, %s, tem %d gols.';
$string = sprintf($formato, $artilheiro, $gols);
echo '<pre>';
echo $string;
