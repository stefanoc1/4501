<!-- INÍCIO - BREADCRUMB -->
<div id="breadcrumb" itemprop="breadcrumb">
    <div class="conteudo_padrao">
        <a href="?q=index.html" title="Home">Home</a> > <a href="?q=quem_somos.html" title="Sobre a Dexter">Sobre a Dexter</a> > <a href="?q=nossos_valores.html" title="Nossos Valores">Nossos Valores</a>
    </div>
</div>
<!-- FIM - BREADCRUMB -->
<div id="corpo" class="conteudo_padrao">
    <h1 class="titulo_site">Nossos Valores</h1>

    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Minus, et, laboriosam eveniet qui a nobis omnis quibusdam facilis placeat ipsam voluptate consequuntur blanditiis reiciendis? Rerum, harum mollitia placeat deleniti vero.</p>
    
    <ul>
        <li>Item 1</li>
        <li>Item 2</li>
        <li>Item 3</li>
        <li>Item 4</li>
    </ul>
</div>
