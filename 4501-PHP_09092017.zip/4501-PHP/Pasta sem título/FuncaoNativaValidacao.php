<?php
/*
$variavel = "Teste";

echo "Funcao isset";
echo '<pre>';
if (isset($variavel)) {
	echo "A variavel nao existe!";
}
echo '<pre>';
*/

echo "Funcao unset";
echo '<pre>';
$variavel2 = "Teste2";
echo '<pre>';
	set ($variavel2);
	echo "A variavel criada!";
	set ($variavel2);
	echo "A variavel deletada!";

echo '<pre>';