<?php

class Caneta
{
	private static $tamanho = 10;
	private $cor;

	public function __construct($cor)
	{
		$this->cor = $cor;
	}

	public function getCor()
	{
		return $this->cor;		
	}

	public function getTamanho()
	{
		return self::$tamanho;		
	}
}

$canetaA = new Caneta('Azul');
$canetaB = new Caneta('Preta');
$canetaC = new Caneta('Vermelha');

echo "<p>Caneta 1</p>";
echo "<p>Cor: ".$canetaA->getCor()."</p>";
echo "<p>Tamanho: ".$canetaA->getTamanho()."</p>";
echo "<hr/>";
echo "<p>Caneta 2</p>";
echo "<p>Cor: ".$canetaB->getCor()."</p>";
echo "<p>Tamanho: ".$canetaB->getTamanho()."</p>";
echo "<hr/>";
echo "<p>Caneta 3</p>";
echo "<p>Cor: ".$canetaC->getCor()."</p>";
echo "<p>Tamanho: ".$canetaC->getTamanho()."</p>";