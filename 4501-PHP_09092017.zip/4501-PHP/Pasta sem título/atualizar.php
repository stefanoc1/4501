<h1>Atualizar usuario<h1>
<form action="?acao=Atualizar" method="post">
     	<input type="text" name="usuarioAtual">
        <input type="text" name="novoUsuario">
        <input type="submit" value="Atualizar">
</form>

<?php


	var_dump($_GET);

	require 'conexao.php';

// alltualizarUsuario ('stefano', nome=\'maria\'')

	funcion atualizarUsuario ($usuarioAtual, $novoUsuario) {
	    $query = "UPDATE usuarios SET nome=$usuarioAtual WHERE nome=$novoUsuario";
	}

			if($_GET['acao'] == 'Atualizar') {
			cadastrarUsuario($_POST = 'nome', $_POST = 'senha');
	}