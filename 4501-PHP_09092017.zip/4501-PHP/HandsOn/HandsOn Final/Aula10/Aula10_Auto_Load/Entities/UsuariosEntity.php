<?php
namespace Entities;

class UsuariosEntity
{

    protected $nome = 'Aline dos Santos';

    public function getNome()
    {
        return $this->nome;
    }
}