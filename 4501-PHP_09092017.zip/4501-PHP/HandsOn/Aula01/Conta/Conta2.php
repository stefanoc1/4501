<?php
//Princi
class Conta
{
	public $nroConta;
	private $saldo = 0;

	public function verSaldo() {
		return $this->saldo;
	}

	public function depositar($valor) {
		$this->saldo += $valor;	
	}

	public function retirar($valor) {
		if($this->saldo -= $valor <0) {
			echo 'Retirada maior que saldo ';
		} else {
			$this->saldo -= $valor;
		}
	}
}

$conta1 = new Conta();

$conta1->depositarSaldo(50);
$conta1->retirarSaldo(45);
echo '<br>';
echo $conta1->verSaldo();
?>