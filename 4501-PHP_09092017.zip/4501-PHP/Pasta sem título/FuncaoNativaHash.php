<?php

echo '<pre>';
echo 'Exemplo md5';
$String = 'Exemplo';
echo md5 ($String);