<?php
//Exemplo array_combine
$chaves = [
'Galaxy S8',
'Moto X3',
'iPhone 8',
'iPhone 8',
'Symbian'
];

//var_dump($celulares);

$valores = [
'Android Custom - Touch Wiz',
'Android Nativo',
'iOS',
'iOS',
'Firefox OS'
];

$maisvalores = [
'Android Custom - Touch Wiz',
'Android Nativo',
'iOS',
'Chrome',
'Firefox OS'
];
//var_dump ($sistemas);

$sistema_de_cada_celular = array_combine($chaves, $valores);//; $celulares, $sistemas)
echo '<pre>';
echo 'Exemplo: array_combine';
echo '<pre>';
var_dump($sistema_de_cada_celular);
echo '<pre>';

//Exemplo array_count_values
echo '<pre>';
var_dump(array_count_values($valores));
echo '<pre>';

echo '<strong>Exemplo array_dif<strong>';
echo '<pre>';
var_dump(array_diff($valores, $maisvalores));
echo '<pre>';

echo '<pre>';
echo 'Exemplo: in_array';
echo '<pre>';
var_dump(in_array($valores));
echo '<pre>';


$csv = 'Denis, Thiago, William'

$array_csv (explode)
