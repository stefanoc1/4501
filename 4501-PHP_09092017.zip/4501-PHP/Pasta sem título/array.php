<?php

/*$pessoas = array('Joao',
				 'Maria',
				 'Pedro');
print_r($pessoas);*/


$pessoas = array('Joao',
				 'Maria',
				 'Pedro');
var_dump($pessoas);