<h1>Cadastrar usuario<h1>
<form action="?acao=Cadastrar" method="post">
     	<input type="text" name="usuario">
        <input type="password" name="senha">
        <input type="submit" value="Cadastrar">
</form>


<?php

	require 'conexao.php';

	function cadastrarUsuario($nome, $senha) {
		global $$conexao_postgres;

		$sql ="INSERT INTO usuarios (nome, senha) VALUE ($'nome', $'senha')";	
		
		var_dump($conexao_postgres);

		return pg_query($conexao_postgres, $sql);

	}

	if ($_GET['acao'] == 'cadastrar') {
		cadastrarUsuario($_POST['usuario'],$_POST['senha']);
		
	}