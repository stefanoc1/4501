<?php

$v_ou_f = true;
$inteiro = 10;
