<?php

class Conta
{
	public function __set($name, $value)
	{
		echo $name;
		echo '<br>';
		echo $value;
		echo '<br>';
		$this->$name = $value*10;
	}
}
$conta = new Conta();
$conta->saldo = 100;
$conta->saldo = 500;

echo "Saldo atual de R$ {$conta->saldo} reais";