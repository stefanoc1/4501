<?php

function abrirForm($url) {
    return "<form action=$url method=\"post\">";

}

function gerarInput($type = '', $name = '', $placeholder = '') {
    if  ($type == 'submit') {
        return "<input type=$type name=$name>";
        } else {
        return "<input type=$type name=$name placeholder=$placeholder>";
        }
        return ($type == 'submit');
    }
    
function fecharForm() {
    return "</form>";
}

//echo abrirForm('tratar.php');

//   echo gerarInput('text', 'nome', 'Nome');
//   echo gerarInput('password', 'senha', 'Senha');
//   echo gerarInput('submit');

//echo fecharForm();


<form action="tratar.php?login=0" method="post">
    <input type="text" name="Nome">
    <input type="password" name="senha">
    <input type="password" name="confirmasenha">
    <input type="submit">
</form>




