<?php

namespace DexterApp\Admin\Models\Collection;

class Destaque extends \ArrayObject
{
}
