<?php

$nome = "maria da silva";

//Exemplo strtoupper
echo strtoupper ($nome);

//Exemplo strtolower
echo strtolower ($nome);

//Exemplo ucfirst
echo ucfirst ($nome);

//Exemplo ucwords
echo ucwords ($nome);

//Exemplo strlen
echo strlen ($nome);

//Exemplo str_replace
/*echo $string = "The quick brow fox jumpes over the lazy dog";
echo <br/>
echo str_replace ('dog', 'cat', $string;);*/


//Exemplo substr
echo $string1 = "The quick brow fox jumpes over the lazy dog";
echo substr ($string1, 1);

//Exemplo strpos
echo $string2 = "The quick brow fox jumpes over the lazy dog";
echo strpos ($string2, "The");
echo strpos ($string2, "quick");

echo $string3 = "The quick brow fox jumpes over the lazy fox";
echo strpos ($string3, "fox", 17);

//Exemplo strstr
echo $string4 = "The quick brow fox jumpes over the lazy dog";
echo strstr ($string4, "jumpes", true);

//Exemplo trim
echo $string5 = "    The      quick brow fox jumpes     over the lazy dog     ";
var_dump($string5);
trim($string5);
var_dump (trim ($string5));