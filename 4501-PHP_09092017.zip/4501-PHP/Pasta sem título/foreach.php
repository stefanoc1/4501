<?php

/*	$pessoas = 	array ('Joao','Maria', 'Pedro');


foreach ($pessoas as $valor) {
	echo "Olá $valor!<br />";
}*/


/*$temperaturas = array('Janeiro' => 30, 'Fevereiro' => 32, 'Marco' => 29);

foreach ($temperaturas as $chave => $valor) {
	echo "A temperatura media de $chave foi de $valor graus<br />";
}
*/

//Array associativo
$meses = array ('Janeiro' => 1,
				'Fevereiro' => 2,
				'Marco' => 3,
				'Abril' => 4,
				'Maio' => 5,
				'Junho' => 6,
				'Julho' => 7,
				'Agosto' => 8,
				'Setembro' => 9,
				'Outubro' => 10,
				'Novembro' => 11,
				'Dezembro' => 12,
//				'Julho' => "Mes atual",
				);

foreach ($meses as $nomemes => $numeromes) {
	echo "O mes $numeromes é $nomemes<br />";
}