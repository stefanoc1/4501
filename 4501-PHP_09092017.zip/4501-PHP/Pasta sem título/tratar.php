<?php

	$login = (boolean) $_GET['login'];

	if ($login) {
		if ($_POST['senha'] == $_POST['confirmasenha']) {
			echo 'Senhas iguais';
		} else {
			echo 'Senhas nao conferem';
		}
	} else {
		echo 'O parametro e igual a true';		
	}
//var_dump($login);

$nome = $_POST['nome'];
$senha = $_POST['senha']; 
$confirma = $_POST['confirmasenha']; 

if ($_POST) {
    if ($senha === $confirma){
    session_start();
    $_SESSION['nome'] = $nome;
    $_SESSION['senha'] = $senha;
    $_SESSION['confirma'] = $confirma;
    }
}

function validasenha ($senha, $confirmasenha) {
	$senha = $confirmasenha




    if ($validasenha = 1)
        echo 'Senha valida';
    } else {
        echo 'Senha invalida';
}

function logar ($senha, $confirmasenha) {
	session_start();
	$_SESSION [nome] = $nome;
	$_SESSION [senha] = $senha;
	$_SESSION [verificarsenha] = $verificarsenha;
}


function deslogar(){
	return session_destroy();
}