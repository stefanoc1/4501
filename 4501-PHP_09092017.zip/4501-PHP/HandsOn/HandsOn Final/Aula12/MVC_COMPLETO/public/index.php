<?php
use Controller\FrontController;

require '../app/Autoload/autoload.php';

(new FrontController())->run(); 
