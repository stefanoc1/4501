<?php
/*
//Aumento - Reducao de velocidade
	for ($kmh = 0; $kmh <= 20; $kmh++) {
		echo "Velocidade aumentando em $kmh <br />";
		if ($kmh == 20) {
			PararVeiculo($kmh);
		}
	}

	function PararVeiculo ($VelocidadeFinal){
		for ($v = $VelocidadeFinal; $v >0 ; $v--) {
			echo "Velocidade diminuindo $v <br>";
					}
	}*/

//Calculo de media

 $nota1 = 7;
 $nota2 = 5;
 $nota3 = 10;

	function CalcularMedia($nota1, $nota2, $nota3){
		global $nota1;
		global $nota2;
		global $nota3;
		$media = ($nota1 + $nota2 + $nota3) / 3;
			if ($media)}
		return $media;
	}
			echo "A media do periodo é $media <br>";
	
	
/*<?php
$n1=7
$n2=6
$n3=7
$media=($n1+$n2+$n3)/3;
echo "Bem vindo $nome, suas notas são:";
echo "<br><br>Nota 1: $n1 - Nota 2: $n2 - Nota 3: $n3 - Media: $media<br><br> Voce esta ";*/