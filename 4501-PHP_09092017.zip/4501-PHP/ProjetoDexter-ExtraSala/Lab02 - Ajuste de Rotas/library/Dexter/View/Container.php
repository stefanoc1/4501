<?php

namespace Dexter\View;

/**
 * Classe Helper para armazenar informações que serão enviadas para a View
 */
class Container extends \ArrayObject
{
}
