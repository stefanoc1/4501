<?php

class Model
{

    public function getDados()
    {
        return [
            'nome' => 'Lucia Couto',
            'email' => 'lucia.couto@gmail.com'
        ];
    }
}