<?php

namespace DexterApp\Admin\Models\Collection;

class Mensagem extends \ArrayObject
{
}
