<?php

	require 'conexao.php';

	function  listarnovo(){

		global $conexao_postgres;

		$sql = "SELECT * FROM usuarios";	
		
		$resultado = pg_query($sql);

		return pg_fetch_all($resultado);

	} 

	$usuarios = listarnovo();

	foreach ($usuarios as $usuario) {
		echo $usuario ['nome'];
	}


		var_dump($conexao_postgres);

?>

<table>
<?php foreach($usuarios as $usuario): ?>
	<tr>
		<td>Nome: <?= $usuario['nome'] ?></td><td><a href
		="?deletar=<?= $usuario['id']?>">Excluir</a><td
		>
	<tr>
<?php endforeach;?>
<table>