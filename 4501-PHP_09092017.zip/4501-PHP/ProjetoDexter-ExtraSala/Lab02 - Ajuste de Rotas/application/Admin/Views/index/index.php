<p class="text"><?= ucfirst($this->user) ?>, seja bem-vindo ao Painel Administrador!</p>
<p class="text">Selecione uma opção ao lado.</p>
