<?php

$dsn = 'pgsql:host=localhost;dbname=dexter';
$user = 'usuario_dexter';
$pass = '123456';

$dados = new PDO($dsn, $user, $pass);

var_dump($dados);

$dados->exec('CREATE TABLE clientes(id SERIAL, nome VARCHAR(255), email VARCHAR(255))');

$db_postgres->exec("INSERT INTO clientes(nome, email) VALUES ('4linux 1', 'forlinux@4linux.com.br')");

$db_postgres->exec("INSERT INTO clientes(nome, email) VALUES ('4linux 2', 'forlinux@4linux.com.br')");