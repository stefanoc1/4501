<?php
/*
class Conta
{
	private $saldo = 0;

	public function __contruct($saldoInicial)
	{
	return $this->$saldoInicial;
	{

	public function getSaldo()
	{
	return $this->saldo;
	}
}
$conta = new Conta(50);
echo "Saldo atual de R$ ",conta->getSaldo()," reais";

*/



class Conta
{
	private $saldo = 0;

	public function __contruct($saldoInicial)
	{
	return $this->$saldoInicial;
	echo $this->saldo;
	}

	public function __destruct()
	{
	echo "Destruindo a conta";
	}
}

$conta = new Conta(50);



