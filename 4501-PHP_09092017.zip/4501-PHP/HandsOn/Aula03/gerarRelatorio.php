<?php

trait geradorRelatorio
{
	public function log($message)
	{

	}
}

class 
{

}

class X extends Z
{
	use geradorRelatorio;

	public function save () 
	{

	}
}

$classX = new X();
$classX->save();