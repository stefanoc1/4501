<?php

// Criando uma classe no PHP
// Para definição do nome usamos o padrão camelcase(Sempre iniciando com letra Maiuscula)
class Contas
{
    // Atributos ou propriedades(visibilidade nome)
    public $saldo;

    public $titular;
    
    // Metodos (visibilidade nome)
    // Metodos podem ou não receber parâmetros, e podem ou não retornar alguma coisa;
    public function sacar()
    {}

    public function depositar()
    {}
}