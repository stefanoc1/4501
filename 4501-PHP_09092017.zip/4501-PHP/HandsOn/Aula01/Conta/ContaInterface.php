<?php

interface funcoesConta
{
	public function verSaldo();
	public function depositar();
	public function retirar();
}

class interfaceConta implements funcoesConta
{


}


