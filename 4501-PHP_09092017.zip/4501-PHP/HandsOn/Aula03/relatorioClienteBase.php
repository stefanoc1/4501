<?php

relCliente

$relCliente->gerarBanco();;
$relCliente->gerarCabecalho();
$relCliente->gerarCorpo();
$relCliente->gerarRodape();
