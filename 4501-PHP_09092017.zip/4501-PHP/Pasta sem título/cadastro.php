<h1>Cadastrar usuario<h1>
<form action="?acao=Cadastrar" method="post">
     	<input type="text" name="usuario">
        <input type="password" name="senha">
        <input type="submit" value="Cadastrar">
</form>

<?php
	

	var_dump($_GET);

	require 'conexao.php';

	$usuario = $_POST['usuario'];
	$senha = $_POST['senha'];
	
	function cadastrarUsuario ($usuario, $senha) {
		global $conexao;

		$query = "INSERT INTO usuarios (nome, senha) VALUES (\"'$usuario'\", \"'$senha'\")";

	return mysqli_query($conexao, $query);

	}

		if($_GET['acao] == 'cadastrar') {
			cadastrarUsuario($_POST = 'nome', $_POST = 'senha');
	

 
        <?php
            $nome = $_POST["nome"];
            $user = $_POST["user"];
            $pass = $_POST["pass"];
            
            $inserir = "INSERT INTO usuarios (id, nome, usuario, senha) VALUES (NULL, '$nome', '$user', '$pass');";
            mysqli_query($conexao, $inserir) or die (mysqli_error($conexao));
            echo"Você foi cadastrado com sucesso. Clique <a href='login.html'>aqui</a> para fazer log-in.";