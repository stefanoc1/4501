<?php

class Conta
{
	public function __get($name, $value)
	{
	return $this->$name = $value;
	{

}
$conta = new Conta();
echo "Saldo atual de R$ ",conta->saldo()," reais";