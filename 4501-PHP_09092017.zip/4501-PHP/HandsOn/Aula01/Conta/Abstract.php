<?php

abstract class FormaGeometrica
{
	public function getTipo()
	{
		return $this->tipo;
	}

	public function getArea()
	{
		return $this->area;
	}

	abstract public function calcularArea();

}

class Quadrado extends FormaGeometrica
{
	
	public function __construct ($tamanho){
		$this->tamanho = $tamanho;
		$this->calcularArea();

	}
	public $tipo = 'Quadrado';
	public $tamanho = 0;
	
	public function calcularArea() {
		$this->area = $this->tamanho*=$this->tamanho;	
	}
}

class Circulo extends FormaGeometrica
{
	public function __construct ($tamanho){
		$this->tamanho = $tamanho;
		$this->calcularArea();

	}
	public $tipo = 'Circulo';
	public $tamanho = 0;

	public function calcularArea() {
		$this->area = 3.14*($this->tamanho*$this->tamanho);	
	}
}

$quadrado = new Quadrado(10);
$circulo = new Circulo(10);
echo $quadrado->getTipo();
echo '<br>';
echo $quadrado->getArea();
echo '<br>';
echo '<br>';
echo $circulo->getTipo();
echo '<br>';
echo $circulo->getArea();