<?php

namespace DexterApp\Front\Models\Collection;

/**
 * Coleção de funcionalidades
 */
class Funcionalidade extends \ArrayObject
{
}
