<?php

	$pessoas = 	array (
		'inteiro' => 1,
		99 => "Maria",
		1.25,
		'meuoutroarray' =>
		array(
			"Silva",
			"Lima"
			)
		);
	
	$mais_pessoas = [
	'inteiro' => 1,
	99 => "Maria",
	1.25,
	'meuoutroarray' => [
			"Silva",
			"Lima"
			]
	];

	$sobrenome = $mais_pessoas['meuoutroarray'[0]];

	var_dump($mais_pessoas);