<?php

namespace DexterApp\Admin\Models\Collection;

class User extends \ArrayObject
{
}
