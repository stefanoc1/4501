<?php
class Titular
{
    public $nome = 'Aline dos Santos';
}