<?php

	include 'namespace_ex.php';
	use Modelo\Cliente as ModeloCliente; //Alias (apelido)

	$cliente = new Modelo\Cliente('Stefano');

	echo $cliente->getNome();