<?php

namespace DexterApp\Admin\Models\Exceptions;

/**
 * Exception que representa usuário e/ou senha inválidos
 */
class InvalidUserOrPasswordException extends \InvalidArgumentException
{
}
