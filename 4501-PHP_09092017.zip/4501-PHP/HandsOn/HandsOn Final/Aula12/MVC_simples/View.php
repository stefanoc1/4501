<?php

class View
{
    public function __construct($dados)
    {
        require 'executar.phtml';
    }
}