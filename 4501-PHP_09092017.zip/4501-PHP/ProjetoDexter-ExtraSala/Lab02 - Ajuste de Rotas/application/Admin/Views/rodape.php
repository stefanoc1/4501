            <!-- INÍCIO - RODAPÉ DO SITE -->
            <footer id="footer">
            <p>&copy; <?= date('Y') ?> Dexter Courier Logistica S/A.</p>
            </footer>
            <!-- FIM - RODAPÉ DO SITE -->

            <script src="admin/assets/plugins/slicknav/jquery.slicknav.js"></script>
            <script src="admin/assets/plugins/tablesorter/jquery.tablesorter.js"></script>
            <script src="admin/assets/plugins/selectric/jquery.selectric.js"></script>
            <script src="admin/assets/plugins/selectmultiple/jquery.multiple.select.js"></script>
            <script src="admin/assets/js/script.js"></script>         
    </body>
</html>
