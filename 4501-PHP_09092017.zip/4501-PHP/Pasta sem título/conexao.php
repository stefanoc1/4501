<?php

	//$conexao = mysqli_connect('localhost', 'admin', '4linux@', 'projeto');
	$conexao_postgres = pg_connect("host=localhost dbname=projeto user=admin password=4linux@");

	var_dump($conexao_postgres);