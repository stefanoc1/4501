<?php
class Banner
{
 //Tabela Banners
    private $id;
    private $nome;
    private $descricao;
    private $url;


    public function getId()
    {
        return $this->id;
    }

    public function setId($id)
    {
     	$this->id = $id;  
    }

    public function getNome()
    {
        return $this->nome;
    }

    public function setNome($nome)
    {
        $this->nome = $nome;
    }

    public function getDescricao()
    {
        return $this->descricao;
    }

    public function setDescricao($descricao)
    {
        $this->descricao = $descricao;
    }

    public function getUrl()
    {
        return $this->url;
    }

    public function setUrl($url)
    {
        $this->url = $url;
    }

    public function isNew()
    {
        return is_null($this->id);
    }
}
//PDO
$dsn = 'pgsql:host=localhost;dbname=dexter';
$user = 'usuario_dexter';
$pass = '123456';

$pdo = new PDO($dsn, $user, $pass);

echo '<pre>';

var_dump($pdo);

$prepare = $pdo->prepare('SELECT * FROM banners');
$prepare->execute();
$result = $prepare->fetchAll(PDO::FETCH_ASSOC);

$banners = [];

foreach ($result as $banner)
{
    $obj = new Banner();//criado o objeto banner

    $obj->setId($banner['id']);
    $obj->setNome($banner['nome']);
    $obj->setDescricao($banner['descricao']);
    $obj->setUrl($banner['url']);

    $banner[] = $obj;


}
    var_dump($banners);



//Prepared Statements
//	$query = 'UPDATE banners SET nome = :nome, descricao = :descricao, url = :url where id = :id';

	$query = 'INSERT INTO banners SET (nome, descricao, url) VALUES (:nome, :descricao, :url)';
	
	$array = array
	(
		':nome'=> 'Nome do banner',
		'descricao' => 'Descricao do banner',
		'url' => 'url do banner',
//		'id' => 11
		);

	$prepare = $pdo->prepare('SELECT * FROM banners');
	$prepare->execute();

