<?php


public abstract class RelatorioClienteBase
{
        // Métodos das partes do relatório
        public abstract void Inicializar();
        public abstract void GerarCabecalho();
        public abstract void GerarCorpo();
        public abstract void GerarRodape();
}

public class RelatorioClientePJ : RelatorioClienteBase
{
    List<ClientePJ> lista = null;
 
    public override void Inicializar()
    {
        lista = ClientePJ.selecionar(DataInicio, DataFim);
    }
 
    public override void GerarCabecalho()
    {
        Console.WriteLine("----------------------------");
        Console.WriteLine(" RELATÓRIO DE CLIENTES");
        Console.WriteLine(" PESSOA JURÍDICA");
        Console.WriteLine("----------------------------");
        Console.WriteLine(String.Format("Impressão em: {0}", DateTime.Now.ToString()));
        Console.WriteLine("----------------------------");
    }
 
    public override void GerarCorpo()
    {
        Console.Write("Código\t");
        Console.Write("Razão social\t");
        Console.Write("CNPJ\t\t\t");
        Console.Write("IE\t");
        Console.WriteLine();
 
        foreach (ClientePJ cliente in lista)
        {
            Console.Write(String.Format("{0}\t", cliente.Codigo));
            Console.Write(String.Format("{0}\t", cliente.RazaoSocial));
            Console.Write(String.Format("{0}\t", cliente.CNPJ));
            Console.Write(String.Format("{0}\t", cliente.IE));
            Console.WriteLine();
        }
    }
 
    public override void GerarRodape()
    {
        Console.WriteLine("----------------------------");
        Console.WriteLine(String.Format("Quantidade de registros: {0}", lista.Count));
    }
}


public class RelatorioClientePF : RelatorioClienteBase
{
    List<ClientePF> lista = null;
 
    public override void Inicializar()
    {
        lista = ClientePF.selecionar(DataInicio, DataFim);
    }
 
    public override void GerarCabecalho()
    {
        Console.WriteLine("-------------------------------");
        Console.WriteLine(" RELATÓRIO DE CLIENTES");
        Console.WriteLine(" PESSOA FÍSICA");
        Console.WriteLine("-------------------------------");
        Console.WriteLine(String.Format("Impressão em: {0}", DateTime.Now.ToString()));
        Console.WriteLine("-------------------------------");
    }
 
    public override void GerarCorpo()
    {
        Console.Write("Código\t");
        Console.Write("Nome\t\t\t");
        Console.Write("CPF\t\t\t");
        Console.Write("RG");
        Console.WriteLine();
 
        foreach (ClientePF cliente in lista)
        {
            Console.Write(String.Format("{0}\t", cliente.Codigo));
            Console.Write(String.Format("{0}\t\t", cliente.Nome));
            Console.Write(String.Format("{0}\t\t", cliente.CPF));
            Console.Write(String.Format("{0}\t", cliente.RG));
            Console.WriteLine();
        }
    }
 
    public override void GerarRodape()
    {
        Console.WriteLine("-------------------------------");
        Console.WriteLine(String.Format("Quantidade de registros: {0}", lista.Count));
    }
}



public class RelatorioClienteCreator
  {
      RelatorioClienteBase _report;
 
      public RelatorioClienteCreator(RelatorioClienteBase report)
      {
          _report = report;
      }
 
      public void GerarRelatorio()
      {
          _report.Inicializar();
          _report.GerarCabecalho();
          _report.GerarCorpo();
          _report.GerarRodape();
      }
  }


  RelatorioClienteCreator cPF =
new RelatorioClienteCreator(new RelatorioClientePF());
cPF.GerarRelatorio();


public class RelatorioCliente
{
    string tipoCliente;
 
    public void GerarRelatorio(string tipoCliente)
    {
        this.tipoCliente = tipoCliente;
        GerarCabecalho();
        GerarCorpo();
        GerarRodape();
    }
 
    private void GerarCabecalho()
    {
        if (tipoCliente == "PJ")
        {
            // Exibir cabeçalho de pessoa juridica
        }
        else
        {
            // Exibir cabeçalho de pessoa fisica
        }
    }