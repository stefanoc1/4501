<!-- INÍCIO - BREADCRUMB -->
<div id="breadcrumb" itemprop="breadcrumb">
    <div class="conteudo_padrao">
        <a href="?q=index.html" title="Home">Home</a> > <a href="?q=quem_somos.html" title="Sobre a Dexter">Sobre a Dexter</a> > <a href="?q=quem_somos.html" title="Quem Somos">Quem Somos</a>
    </div>
</div>
<!-- FIM - BREADCRUMB -->

<div id="corpo" class="conteudo_padrao">
    <h1 class="titulo_site">Quem Somos</h1>

    <img src="assets/images/banners/banner-sobre.jpg" alt="Quem Somos" />
        
    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Minus, et, laboriosam eveniet qui a nobis omnis quibusdam facilis placeat ipsam voluptate consequuntur blanditiis reiciendis? Rerum, harum mollitia placeat deleniti vero.</p>
    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nisi, ut, quo deleniti fugit illum repudiandae aperiam cupiditate quis aliquam eaque.</p>
    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aperiam, error, deserunt, temporibus, rerum facilis atque eligendi nesciunt deleniti unde iste officia placeat adipisci et eveniet voluptate reiciendis autem quo officiis.</p>
    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Minus, et, laboriosam eveniet qui a nobis omnis quibusdam facilis placeat ipsam voluptate consequuntur blanditiis reiciendis? Rerum, harum mollitia placeat deleniti vero.</p>
    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nisi, ut, quo deleniti fugit illum repudiandae aperiam cupiditate quis aliquam eaque.</p>
    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aperiam, error, deserunt, temporibus, rerum facilis atque eligendi nesciunt deleniti unde iste officia placeat adipisci et eveniet voluptate reiciendis autem quo officiis.</p>
</div>

