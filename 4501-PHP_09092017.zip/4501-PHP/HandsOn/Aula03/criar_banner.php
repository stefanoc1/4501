<?php
class Banner
{
 //Tabela Banners
  
    private $id;
    private $nome;
    private $descricao;
    private $url;

    public function getId()
    {
        return $this->id;
    }

    public function setId($id)
    {
        $this->id = $id;
    }

    public function getNome()
    {
        return $this->nome;
    }

    public function setNome($nome)
    {
        $this->nome = $nome;
    }

    public function getDescricao()
    {
        return $this->descricao;
    }

    public function setDescricao($descricao)
    {
        $this->descricao = $descricao;
    }

    public function getUrl()
    {
        return $this->url;
    }

    public function setUrl($url)
    {
        $this->url = $url;
    }
//Crie um método em todas as entidades chamado isNew(), ele deve retornar um true caso o id da entidade esteja preenchido ou false caso contrário
    
    public function isNew()
    {
        return is_null($this->id);
    }
}

    private $nome;
    private $descricao;
    private $url;

$dsn = 'pgsql:host=localhost;dbname=dexter';
$user = 'usuario_dexter';
$pass = '123456';

$db_postgres = new PDO($dsn, $user, $pass);

var_dump($db_postgres);

$db_postgres->exec("INSERT INTO banners(nome, descricao, url) VALUES ('Frete Courrier', 'Entregas via Courrier', 'banner.jpg')");

$db_postgres->exec("INSERT INTO banners(nome, descricao, url) VALUES ('Entrega agendada', 'Entregas vcom agendamento previo', 'banner.jpg')");