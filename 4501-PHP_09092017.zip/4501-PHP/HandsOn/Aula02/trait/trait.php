<?php

trait LogTrait
{
	public function log($message)
	{
		$log = date("d.m.y").' '.date("H:i:s").': '.$message;
		file_put_contents('log.txt', $log, FILE_APPEND);
		echo $message;
	}
}

class Z
{

}

class X extends Z
{
	use LogTrait;

	public function save () 
	{
		$this->log = $this->log('Arquivo de Trait foi aberto dia '.date("d.m.y").' '.date("H:i:s"));
		return $this->log;
	}
}

$classX = new X();
$classX->save();