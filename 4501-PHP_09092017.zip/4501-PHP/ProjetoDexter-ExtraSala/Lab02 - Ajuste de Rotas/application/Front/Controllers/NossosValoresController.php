<?php

namespace DexterApp\Front\Controllers;

use Dexter\Router\Request   as R;
use Dexter\View\View        as V;

use DexterApp\AbstractController;

class NossosValoresController extends AbstractController
{

    /**
     * Página inicial
     */
    public function actionIndex(R $req, V $view)
    {
    }
}
