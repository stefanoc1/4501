<?php

interface GerarTabela
{
	public function Inicializar();
	public function GerarCabecalho();
	public function GerarCorpo();
	public function GerarRodape();
}

trait gerarRelatorio
{
	public function GerarTabela()
	{

	}
}

abstract class PJ implements gerarTabela

{

	use GerarRelatorio;

	public function Inicializar()
	{
			
	}
	public function GerarCabecalho()
	{
			
	}

	public function GerarCorpo()
	{
			
	}

	public function GerarRodape()
	{
			
	}
}

abstract class PF implements gerarTabela
{

	use GerarRelatorio;

	public function Inicializar()
	{
			
	}
	public function GerarCabecalho()
	{
			
	}

	public function GerarCorpo()
	{
			
	}

	public function GerarRodape()
	{
			
	}
}

class ClientePJ extends PJ
{
	private $codigo = 0;
	private $nome = '';
	private $cnpj = '';
	private $ie = '';
	private $im = '';
}

class ClientePF extends PF
{
	private $codigo = 0;
	private $nome = '';
	private $rg = '';
	private $cpf = '';
}