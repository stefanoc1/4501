<?php

namespace DexterApp\Admin\Models\Collection;

class Cliente extends \ArrayObject
{
}
