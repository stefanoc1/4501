<?php

//Funcao listar

require 'conexao.php';


//	var_dump($conexao);


	function listar() {
			
			global $conexao;

			var_dump($conexao);

			$sql = "SELECT * FROM usuarios";

			$resultado = mysqli_query($conexao, $sql);


			return mysqli_fetch_array($resultado, 1);

}

	echo "<pre>"; 
	var_dump(listar());


foreach ($usuarios as $users => $valor) {
    echo "$users<br />";
     
}

