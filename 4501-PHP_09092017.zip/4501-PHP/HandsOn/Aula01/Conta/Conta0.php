<?php

class Conta
{
	public $nroConta;
	private $saldo = 0;

	public function verSaldo() {
		return $this->saldo;
	}

	public function setarSaldo($valor) {
		$this->saldo = $valor;
	}
}

$conta1 = new Conta();

$conta1->setarSaldo ('R$15,00');
echo $conta1->verSaldo();




?>